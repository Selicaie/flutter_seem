import 'models/user.dart';
class Globals {
  static String token; //oauth token
  static UserIdentity user;
}