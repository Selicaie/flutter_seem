import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:instructions_app/services/database.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PushNotificationsManager {
  var context;

  BuildContext get currentContext => context;
  // PushNotificationsManager._();

  // factory PushNotificationsManager() => _instance;

  // static final PushNotificationsManager _instance = PushNotificationsManager._();

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  bool _initialized = false;
  //BuildContext get currentContext => _currentElement;
 saveToken() async {
     // For testing purposes print the Firebase Messaging token
      String token = await _firebaseMessaging.getToken();
      print("FirebaseMessaging token: $token");
      SharedPreferences prefs = await SharedPreferences.getInstance(); 
       prefs.setString("token", token);
      
      // if(token!=null)
      // {
      //   String uid = prefs.getString('uid') ?? "";
      //   if(uid!="")
      //     await DatabaseService(uid:uid).saveDeviceToken(token);
      // }
  }
  Future<void> init() async {
    if (!_initialized) {
      // For iOS request permission first.
      // if (Platform.isIOS) {
      // _firebaseMessaging.requestNotificationPermissions(IosNotificationSettings(sound: true, badge: true, alert: true, provisional: false));
    //}

_firebaseMessaging.requestNotificationPermissions(IosNotificationSettings(sound: true, badge: true, alert: true, provisional: false));
    //_firebaseMessaging.requestNotificationPermissions();
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        //Navigator.of(context).pushNamed("/instructions");
        //Navigator.of(context).pushNamed(message['screen']).
        //print("onMessage: "+message['notification']['title']);
        print("onMessage: $message");
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
      },);
     // _firebaseMessaging.configure();

      
      await saveToken();
        
      _initialized = true;

      
    }
  }
}