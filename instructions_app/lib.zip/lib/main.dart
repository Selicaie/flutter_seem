import 'package:flutter/material.dart';
//import 'package:instructions_app/auth.dart';
import 'package:instructions_app/routes.dart';
import 'package:instructions_app/services/firebaseAuth.dart';
import 'package:provider/provider.dart';

import 'models/users.dart';

void main() => runApp(new LoginApp());

class LoginApp extends StatelessWidget {

  
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    //  return StreamProvider<User>.value(
    //   value: AuthService().user,
    //   child:  MaterialApp(
    //   debugShowCheckedModeBanner: false,
    //   title: 'Instructions',
    //   theme: new ThemeData(
    //     primarySwatch: Colors.red,
    //   ),
    //   routes: routes,
    // )
    // );
    return new MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Instructions',
      theme: new ThemeData(
        primarySwatch: Colors.red,
      ),
      routes: routes,
    );
  }


}


// import 'package:flutter/material.dart';
// //import 'package:instructions_app/screen/login/login.dart';
// import 'package:instructions_app/screens/login/login.dart';

// void main() => runApp(MyApp());

// class MyApp extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Instructions',
//       theme: ThemeData(
//         // This is the theme of your application.
//         //
//         // Try running your application with "flutter run". You'll see the
//         // application has a blue toolbar. Then, without quitting the app, try
//         // changing the primarySwatch below to Colors.green and then invoke
//         // "hot reload" (press "r" in the console where you ran "flutter run",
//         // or simply save your changes to "hot reload" in a Flutter IDE).
//         // Notice that the counter didn't reset back to zero; the application
//         // is not restarted.
//         primarySwatch: Colors.deepPurple,
//       ),
//       home: LoginScreen(title: 'Instructions Login'),
//     );
//   }
// }
